
package com.mycompany.expedicionesespaciales_pp1;


public class NaveCarguero extends NavesEspaciales implements Exploracion{
    private static final int CAPACIDAD_MIN = 100;
    private static final int CAPACIDAD_MAX = 500;
    private int capacidad;

    public NaveCarguero(int capacidad,String nombre, int capacidadTripulacion, String anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        if (capacidad >= NaveCarguero.CAPACIDAD_MIN && capacidad <= NaveCarguero.CAPACIDAD_MAX){
            this.capacidad = capacidad; 
        } else{
            throw new PesoFueraRangoException();
        }
    }

    @Override
    public String toString() {
        return super.toString() + "\nNaveCarguero\n" + "Capacidad = " + capacidad ;
    }

    
    
    
    @Override
    public void explorar() {
        System.out.println("Explorando proximas cargas!!");
    
    }

   
   @Override
    public String mostrarNave() {
        toString();
    }
    
    
}
