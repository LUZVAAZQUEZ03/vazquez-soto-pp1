
package com.mycompany.expedicionesespaciales_pp1;


public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO;
    
     @Override
    public String toString() {
        String cadena = super.toString();
        return cadena.substring(0, 1) + cadena.substring(1).toLowerCase();
    }
    
}
