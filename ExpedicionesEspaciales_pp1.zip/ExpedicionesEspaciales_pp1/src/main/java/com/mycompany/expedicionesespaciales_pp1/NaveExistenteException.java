
package com.mycompany.expedicionesespaciales_pp1;


public class NaveExistenteException extends RuntimeException{
    private static final String MESSAGE = "La nave que intenta ingresar ya existe!";
    
    public NaveExistenteException() {
        super(MESSAGE);
    }

    
}
