
package com.mycompany.expedicionesespaciales_pp1;


public class ExpedicionesEspaciales_pp1 {

    public static void main(String[] args) {
        
        AgenciaEspacial spaceX = new AgenciaEspacial();
        
        CruceroEstelar crucero1 = new CruceroEstelar(5000,"titanic",500,"2029");
        CruceroEstelar crucero3 = new CruceroEstelar(5000,"titanic",500,"2029");
        
        
        try{
            NaveCarguero c1 = new NaveCarguero(300,"Galactica",123,"2026");
            NaveCarguero c2 = new NaveCarguero(300,"GalacticaII",234,"2026");
            
            NaveExploracion ne1 = new NaveExploracion(TipoMision.CONTACTO,"explorador jupiter",800,"2030");

            spaceX.agregarNave(c1);
            spaceX.agregarNave(c2);
            spaceX.agregarNave(ne1);
            spaceX.agregarNave(crucero1);
            spaceX.agregarNave(crucero3);
            spaceX.agregarNave(null);
            
        
        }catch(NullPointerException ex){
            System.out.println(ex.getMessage());
        }catch(PesoFueraRangoException ex){
            System.out.println(ex.getMessage());
        }catch(NaveExistenteException ex){
            System.out.println(ex.getMessage());
        }

        
        
        spaceX.mostarNaves();
        spaceX.exploran();
        
        
        
    }
}
