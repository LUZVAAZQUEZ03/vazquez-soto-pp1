package com.mycompany.expedicionesespaciales_pp1;

public class PesoFueraRangoException extends RuntimeException{
    private static final String MESSAGE = "El peso que desea transportar no es aceptable";
    
    
    public PesoFueraRangoException() {
        super(MESSAGE);
    }

    
}
