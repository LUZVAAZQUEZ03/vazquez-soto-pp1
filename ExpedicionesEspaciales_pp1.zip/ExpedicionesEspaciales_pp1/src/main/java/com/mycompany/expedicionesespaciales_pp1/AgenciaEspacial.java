
package com.mycompany.expedicionesespaciales_pp1;

import java.util.List;
import java.util.ArrayList;


public class AgenciaEspacial {
    private List<NavesEspaciales> navesEspaciales = new ArrayList<>();

    public AgenciaEspacial() {
    }
    
    
    public void agregarNave(NavesEspaciales nave){
        if (nave == null){
            throw new NullPointerException("No cargaste una nave!");
        }
        if (navesEspaciales.contains(nave)){
            throw new NaveExistenteException();
        }
        navesEspaciales.add(nave);
        
    }
    
        
    public void mostarNaves(){
        if (navesEspaciales == null){
            System.out.println("No hay naves aun.");
        }
        for(NavesEspaciales naves: navesEspaciales){
            System.out.println(naves);
        }
        
    }
    public void exploran(){
        for (NavesEspaciales naves : navesEspaciales){
            if (naves instanceof NaveExploracion || naves instanceof NaveCarguero ){
                System.out.println(naves.mostrarNave());
            }
            else{
                System.out.println("esta nave no puede explorar");
                System.out.println(naves.mostrarNave());
            }
            
        }
    }
    
    public boolean puedeExplorar(NavesEspaciales naves){
        return naves instanceof Exploracion;
    }
    
}
