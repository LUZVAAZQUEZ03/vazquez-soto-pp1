
package com.mycompany.expedicionesespaciales_pp1;


public class CruceroEstelar extends NavesEspaciales{
    private int cantidadPasajeros;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidadTripulacion, String anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }
    
    

    @Override
    public String toString() {
        return super.toString() + "CruceroEstelar\n" + "CantidadPasajeros = " + cantidadPasajeros ;
    }

 
    
    @Override
    public String mostrarNave() {
        return toString();
    }
    
    
}
