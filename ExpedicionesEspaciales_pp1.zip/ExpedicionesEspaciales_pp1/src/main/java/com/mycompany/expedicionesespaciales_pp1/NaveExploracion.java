
package com.mycompany.expedicionesespaciales_pp1;


public class NaveExploracion extends NavesEspaciales implements Exploracion{
    private TipoMision mision;

    public NaveExploracion(TipoMision mision, String nombre, int capacidadTripulacion, String anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    @Override
    public String toString() {
        return super.toString()+"\nNaveExploracion \n" + "Mision = " + mision ;
    }

    
    
    @Override
    public void explorar() {
        System.out.println("Iniciando mision! \nDe camino a explorar!");
        
    }

    @Override
    public String mostrarNave() {
        toString();
    }
    
    
}
