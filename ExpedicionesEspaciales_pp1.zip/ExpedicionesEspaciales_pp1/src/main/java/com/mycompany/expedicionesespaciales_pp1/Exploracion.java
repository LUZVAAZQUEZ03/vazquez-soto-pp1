
package com.mycompany.expedicionesespaciales_pp1;


public interface Exploracion {
    void explorar();
}
