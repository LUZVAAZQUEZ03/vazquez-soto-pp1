
package com.mycompany.expedicionesespaciales_pp1;

import java.util.Objects;


public abstract class NavesEspaciales {
    private String nombre;
    private int capacidadTripulacion;
    private String anioLanzamiento;

    protected NavesEspaciales(String nombre, int capacidadTripulacion, String anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    @Override
    public String toString() {
        return "Naves Espaciales:\nNombre = " + nombre + "\nCapacidad Tripulacion = " + capacidadTripulacion + "\nAnio Lanzamiento =" + anioLanzamiento;
    }
        
    
    public abstract String mostrarNave();
    
    @Override
    public boolean equals(Object o){
        if (o == this){
            return true;
        }
        if (o == null || getClass() != o.getClass() ){
            return false;
        }
        
        NavesEspaciales other = (NavesEspaciales) o;
        return other.anioLanzamiento.equals(anioLanzamiento) && other.nombre.equals(nombre);
        
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + Objects.hashCode(this.nombre);
        hash = 73 * hash + Objects.hashCode(this.anioLanzamiento);
        return hash;
    }
    
    
}
